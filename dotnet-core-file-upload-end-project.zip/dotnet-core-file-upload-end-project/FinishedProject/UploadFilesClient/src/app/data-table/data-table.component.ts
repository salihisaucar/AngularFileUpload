import { FileServiceService } from './../service/file-service.service';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css'],
})
export class DataTableComponent implements OnInit {
  @Input() public data: any;
  constructor(private service: FileServiceService) {}

  ngOnInit(): void {}
}
