export interface UploadedFile {
  id: string;
  fileName: string;
  fileSize: string;
  uploadedDate: string;
}
