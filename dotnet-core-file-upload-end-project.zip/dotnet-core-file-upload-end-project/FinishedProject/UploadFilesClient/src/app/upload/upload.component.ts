import { FileServiceService } from './../service/file-service.service';
import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { UploadedFile } from '../_interfaces/uploaded-file.model';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css'],
})
export class UploadComponent implements OnInit {
  public progress: number;
  public message: string;
  public name: string;
  public description: string;
  public errorMsg: string;
  public uploadedFile: UploadedFile[] = [];

  @Output() public newEvent = new EventEmitter();

  constructor(private service: FileServiceService) {}
  ngOnInit() {
    this.service.getFiles().subscribe((res) => {
      this.uploadedFile = res as UploadedFile[];
    });
  }

  public uploadFile = (files) => {
    if (files.length === 0) {
      return;
    }

    this.service.uploadFile(files).subscribe((data) => {
      if (data.code === 500) {
        this.message = data.message;
      } else {
        this.message = 'Upload success.';
        this.service.getFiles().subscribe((res) => {
          this.uploadedFile = res as UploadedFile[];
        });
      }
    });
  };
}
