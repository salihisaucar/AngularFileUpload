import { HttpClient, HttpEventType } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class FileServiceService {
  constructor(private http: HttpClient) {}

  public uploadFile(files) {
    let fileToUpload = <File>files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);

    return this.http.post<any>('https://localhost:5001/api/upload', formData);
  }

  public getFiles = () => {
    return this.http.get('https://localhost:5001/api/dataread');
  };
}
