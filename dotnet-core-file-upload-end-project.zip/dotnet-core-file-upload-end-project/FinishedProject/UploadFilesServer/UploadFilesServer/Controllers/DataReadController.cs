﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UploadFilesServer.Interfaces;
using UploadFilesServer.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace UploadFilesServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataReadController : ControllerBase
    {
        private IDataService _dataService;
        public DataReadController(IDataService dataService)
        {
            _dataService = dataService;
        }

        // GET: api/<DataRead>
        [HttpGet]
        public List<TestFile> Get()
        {
            return _dataService.GetAllFiles();
        }

    }
}
