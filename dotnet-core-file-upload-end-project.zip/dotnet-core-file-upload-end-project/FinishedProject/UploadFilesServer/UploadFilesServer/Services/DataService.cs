﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UploadFilesServer.Interfaces;
using UploadFilesServer.Models;
using UploadFilesServer.RunTimeDB;

namespace UploadFilesServer.Services
{
    public class DataService : IDataService
    {
        public List<TestFile> GetAllFiles()
        {
            return AppDB.GetAll();
        }

        public void SaveFile(TestFile testFile)
        {
            AppDB.SaveFile(testFile);
        }

        public bool IsFileAdded(string fileName)
        {
            return AppDB.IsFileAdded(fileName);
        }
    }
}
