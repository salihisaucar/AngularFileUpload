﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using UploadFilesServer.Interfaces;
using UploadFilesServer.Models;

namespace UploadFilesServer.Services
{
    public class UploadService : IUploadService
    {
        private IDataService _dataService;
        private IConfiguration _configuration;
        public UploadService(IDataService dataService, IConfiguration  configuration)
        {
            _dataService = dataService;
            _configuration = configuration;
        }
        public ResponseModel Upload(HttpRequest httpRequest)
        {
            var file = httpRequest.Form.Files[0];
            var folderName = Path.Combine("StaticFiles", "AppFile");
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            var systemFileSize = _configuration.GetValue<int>("FileSize");

            if(IsFileAdded(file.FileName))
                return new ResponseModel() { Code = 500, Message = $"File which is {file.FileName} was Added Before" };

            if (!CheckFileType(GetFileExtension(file.FileName)))
                return new ResponseModel() { Code = 500, Message = $"File Extension must be {_configuration.GetValue<string>("FileExtension")}  " };


            if (file.Length > 0 && file.Length< systemFileSize)
            {
                var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);
                long fileSize = file.Length;

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                Random rnd = new Random();

                _dataService.SaveFile(new TestFile() { Id = rnd.Next(0, int.MaxValue),FileName= fileName,FileSize= fileSize, UploadedDate= DateTime.Now});

                return new ResponseModel() {Code=200,Message="OK" };
            }
            else
            {
                return new ResponseModel() { Code = 500, Message = $"File size must be smaller than {systemFileSize}  " };
            }
        }


        private bool CheckFileType(string fileType)
        {
            var definedTypes = _configuration.GetValue<string>("FileExtension");

            return definedTypes.Contains(fileType);
        }

        private string GetFileExtension(string value)
        {
            var array = value.Split('.');
            return array[array.Length - 1];
        }

        private bool IsFileAdded(string fileName)
        {
            return _dataService.IsFileAdded(fileName);
        }

    }
}
