﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UploadFilesServer.Models;

namespace UploadFilesServer.Interfaces
{
    public interface IDataService
    {
        List<TestFile> GetAllFiles();

        void SaveFile(TestFile testFile);
        bool IsFileAdded(string fileName);
    }
}
