﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UploadFilesServer.Models;

namespace UploadFilesServer.RunTimeDB
{
    public static class AppDB
    {
        private static List<TestFile> testFilesDB;

        public static void SaveFile(TestFile testFile)
        {
            if (testFilesDB == null)
                testFilesDB = new List<TestFile>();

            testFilesDB.Add(testFile);
        }

        public static List<TestFile> GetAll()
        {
            return testFilesDB;
        }

        public static bool IsFileAdded(string fileName)
        {
            if (testFilesDB == null) return false;

            return testFilesDB.Exists((x) => x.FileName == fileName);
        }
    }
}
